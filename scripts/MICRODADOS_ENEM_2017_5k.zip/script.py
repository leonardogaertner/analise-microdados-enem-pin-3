# -*- coding: utf-8 -*-

import pandas as pd
from sqlalchemy import create_engine, text, types
import time
import glob
from io import StringIO
import numpy as np
import os

# --- Configuração do Banco de Dados PostgreSQL ---
DB_USER = 'postgres'
DB_PASS = 'aluno'
DB_HOST = '127.0.0.1'
DB_NAME = 'microdados'
DATABASE_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASS}@{DB_HOST}:5432/{DB_NAME}"

# --- Configurações dos Campos e Arquivos ---
# Lista dos 77 campos originais que serão mantidos dos microdados
campos_str = (
    "NU_INSCRICAO;NU_ANO;TP_FAIXA_ETARIA;TP_SEXO;TP_ESTADO_CIVIL;TP_COR_RACA;"
    "TP_NACIONALIDADE;TP_ST_CONCLUSAO;TP_ANO_CONCLUIU;TP_ESCOLA;TP_ENSINO;"
    "IN_TREINEIRO;CO_MUNICIPIO_ESC;NO_MUNICIPIO_ESC;CO_UF_ESC;SG_UF_ESC;"
    "TP_DEPENDENCIA_ADM_ESC;TP_LOCALIZACAO_ESC;TP_SIT_FUNC_ESC;CO_MUNICIPIO_PROVA;"
    "NO_MUNICIPIO_PROVA;CO_UF_PROVA;SG_UF_PROVA;TP_PRESENCA_CN;TP_PRESENCA_CH;"
    "TP_PRESENCA_LC;TP_PRESENCA_MT;CO_PROVA_CN;CO_PROVA_CH;CO_PROVA_LC;CO_PROVA_MT;"
    "NU_NOTA_CN;NU_NOTA_CH;NU_NOTA_LC;NU_NOTA_MT;TX_RESPOSTAS_CN;TX_RESPOSTAS_CH;"
    "TX_RESPOSTAS_LC;TX_RESPOSTAS_MT;TP_LINGUA;TX_GABARITO_CN;TX_GABARITO_CH;"
    "TX_GABARITO_LC;TX_GABARITO_MT;TP_STATUS_REDACAO;NU_NOTA_COMP1;NU_NOTA_COMP2;"
    "NU_NOTA_COMP3;NU_NOTA_COMP4;NU_NOTA_COMP5;NU_NOTA_REDACAO;Q001;Q002;Q003;Q004;"
    "Q005;Q006;Q007;Q008;Q009;Q010;Q011;Q012;Q013;Q014;Q015;Q016;Q017;Q018;Q019;"
    "Q020;Q021;Q022;Q023;Q024;Q025"
)
campos_desejados = campos_str.upper().split(';')

# --- Configurações do Processo de Carga ---
nome_tabela = 'dados_enem_consolidado'
chunk_size = 50000
upload_chunksize = 1000  # Sub-chunks for to_sql to avoid param overflow

# Garante que o script procure os CSVs no mesmo diretório em que ele está.
script_dir = os.path.dirname(os.path.abspath(__file__))
diretorio_csv = script_dir

# --- Função Central de Transformação e Criação de Novos Campos ---
def aplicar_regras_de_negocio(df, ano):
    if ano == 2024:
        df['Q006'] = df['Q007']
        df['Q024'] = df['Q021']
    elif ano == 2014:
        df['Q005'] = df['Q004']
        mapeamento = {'A': 'B', 'B': 'C', 'C': 'D', 'D': 'E', 'E': 'F', 'F': 'G', 'G': 'H'}
        df['Q001'] = df['Q001'].map(mapeamento)
        df['Q002'] = df['Q002'].map(mapeamento)
        df['Q007'] = None
    
    map_regiao = {
        'AC': 'Norte', 'AP': 'Norte', 'AM': 'Norte', 'PA': 'Norte', 'RO': 'Norte', 'RR': 'Norte', 'TO': 'Norte',
        'AL': 'Nordeste', 'BA': 'Nordeste', 'CE': 'Nordeste', 'MA': 'Nordeste', 'PB': 'Nordeste', 'PE': 'Nordeste', 'PI': 'Nordeste', 'RN': 'Nordeste', 'SE': 'Nordeste',
        'DF': 'Centro-Oeste', 'GO': 'Centro-Oeste', 'MT': 'Centro-Oeste', 'MS': 'Centro-Oeste',
        'ES': 'Sudeste', 'MG': 'Sudeste', 'RJ': 'Sudeste', 'SP': 'Sudeste',
        'PR': 'Sul', 'RS': 'Sul', 'SC': 'Sul'
    }
    map_capitais = {
        'AC': 'Rio Branco', 'AL': 'Maceió', 'AP': 'Macapá', 'AM': 'Manaus', 'BA': 'Salvador', 'CE': 'Fortaleza', 'DF': 'Brasília',
        'ES': 'Vitória', 'GO': 'Goiânia', 'MA': 'São Luís', 'MT': 'Cuiabá', 'MS': 'Campo Grande', 'MG': 'Belo Horizonte',
        'PA': 'Belém', 'PB': 'João Pessoa', 'PR': 'Curitiba', 'PE': 'Recife', 'PI': 'Teresina', 'RJ': 'Rio de Janeiro',
        'RN': 'Natal', 'RS': 'Porto Alegre', 'RO': 'Porto Velho', 'RR': 'Boa Vista', 'SC': 'Florianópolis', 'SP': 'São Paulo', 'SE': 'Aracaju', 'TO': 'Palmas'
    }
    map_renda = {
        'A': 'Nenhuma renda', 'B': 'Até 1 salário mínimo', 'C': 'De 1 a 1,5 salários mínimos', 'D': 'De 1,5 a 2 salários mínimos',
        'E': 'De 2 a 2,5 salários mínimos', 'F': 'De 2,5 a 3 salários mínimos', 'G': 'De 3 a 4 salários mínimos',
        'H': 'De 4 a 5 salários mínimos', 'I': 'De 5 a 6 salários mínimos', 'J': 'De 6 a 7 salários mínimos',
        'K': 'De 7 a 8 salários mínimos', 'L': 'De 8 a 9 salários mínimos', 'M': 'De 9 a 10 salários mínimos',
        'N': 'De 10 a 12 salários mínimos', 'O': 'De 12 a 15 salários mínimos', 'P': 'De 15 a 20 salários mínimos',
        'Q': 'Mais de 20 salários mínimos'
    }
    map_escolaridade = { 'A': 1, 'B': 2, 'C': 3, 'D': 4, 'E': 5, 'F': 6, 'G': 7, 'H': 8 }
    map_escolaridade_reverso = {
        1: 'Nunca estudou', 2: 'Não completou a 4ª série/5º ano', 3: 'Completou a 4ª série/5º ano',
        4: 'Completou a 8ª série/9º ano', 5: 'Completou o Ensino Médio', 6: 'Completou a Faculdade',
        7: 'Completou a Pós-graduação', 8: 'Não sabe'
    }
    map_faixa_etaria_adulto = {
        '1': 'Não', '2': 'Não', '3': 'Não', '4': 'Não', '5': 'Não', '6': 'Não', '7': 'Não', '8': 'Não', '9': 'Não',
        '10': 'Sim', '11': 'Sim', '12': 'Sim', '13': 'Sim', '14': 'Sim', '15': 'Sim', '16': 'Sim', '17': 'Sim',
        '18': 'Sim', '19': 'Sim', '20': 'Sim'
    }

    df['REGIAO_CANDIDATO'] = df['SG_UF_PROVA'].map(map_regiao)
    df['REGIAO_ESCOLA'] = df['SG_UF_ESC'].map(map_regiao)
    df['FLAG_CAPITAL'] = df.apply(lambda row: 'Sim' if pd.notna(row['NO_MUNICIPIO_PROVA']) and row['NO_MUNICIPIO_PROVA'] == map_capitais.get(row['SG_UF_PROVA']) else 'Não', axis=1)
    df['TIPO_ESCOLA_AGRUPADO'] = np.where(df['TP_DEPENDENCIA_ADM_ESC'].isin(['1', '2', '3']), 'Pública', np.where(df['TP_DEPENDENCIA_ADM_ESC'] == '4', 'Privada', None))
    
    cols_notas = ['NU_NOTA_CN', 'NU_NOTA_CH', 'NU_NOTA_LC', 'NU_NOTA_MT']
    for col in cols_notas + ['NU_NOTA_REDACAO']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    
    df['MEDIA_OBJETIVAS'] = df[cols_notas].mean(axis=1).round(2)
    df['MEDIA_GERAL'] = df[cols_notas + ['NU_NOTA_REDACAO']].mean(axis=1).round(2)

    cond_presenca = [
        (df['TP_PRESENCA_CN'].astype(str) == '0') | (df['TP_PRESENCA_CH'].astype(str) == '0') | (df['TP_PRESENCA_LC'].astype(str) == '0') | (df['TP_PRESENCA_MT'].astype(str) == '0'),
        (df['TP_PRESENCA_CN'].astype(str) == '2') | (df['TP_PRESENCA_CH'].astype(str) == '2') | (df['TP_PRESENCA_LC'].astype(str) == '2') | (df['TP_PRESENCA_MT'].astype(str) == '2'),
    ]
    df['INDICADOR_ABSENTEISMO'] = np.select(cond_presenca, ['Ausente em um ou mais dias', 'Eliminado'], default='Presente')
    df['INDICADOR_REDACAO_ZERADA'] = np.where(df['NU_NOTA_REDACAO'] == 0, 'Sim', np.where(df['NU_NOTA_REDACAO'] > 0, 'Não', 'N/A'))
    df['RENDA_FAMILIAR'] = df['Q006'].map(map_renda)
    
    q001_num = df['Q001'].map(map_escolaridade)
    q002_num = df['Q002'].map(map_escolaridade)
    df['ESCOLARIDADE_PAIS_AGRUPADO'] = np.maximum(q001_num, q002_num).map(map_escolaridade_reverso)

    cond_tec = [
        (df['Q024'] == 'A') & (df['Q025'] == 'A'),
        (df['Q024'] != 'A') & (df['Q025'] == 'A'),
        (df['Q024'] == 'A') & (df['Q025'] != 'A'),
        (df['Q024'] != 'A') & (df['Q025'] != 'A')
    ]
    df['INDICE_ACESSO_TECNOLOGIA'] = np.select(cond_tec, ['Nenhum acesso', 'Apenas computador', 'Apenas internet', 'Acesso completo'], default=None)
    
    df['TP_ANO_CONCLUIU'] = pd.to_numeric(df['TP_ANO_CONCLUIU'], errors='coerce')
    df['TEMPO_FORA_ESCOLA'] = np.where(df['TP_ST_CONCLUSAO'].astype(str) == '2', df['NU_ANO'] - df['TP_ANO_CONCLUIU'], None)
    df['FLAG_CANDIDATO_ADULTO'] = df['TP_FAIXA_ETARIA'].astype(str).map(map_faixa_etaria_adulto)

    return df

# --- SCRIPT PRINCIPAL ---
if __name__ == "__main__":
    engine = create_engine(
        DATABASE_URL,
        pool_size=20,        # Base pool: Up from 5
        max_overflow=30,     # Overflow: Up from 10 (total max: 50)
        pool_timeout=60,     # Timeout: Up from 30s
        pool_pre_ping=True   # Validates connections before reuse (catches stale ones)
    )

    arquivos_csv = glob.glob(os.path.join(diretorio_csv, '*.csv'))
    
    if not arquivos_csv:
        print(f"ERRO: Nenhum arquivo .csv foi encontrado no diretório: {diretorio_csv}")
        exit()

    print("--- FASE 1: Analisando cabeçalhos de todos os arquivos... ---")
    master_columns = set(campos_desejados)
    for arquivo in arquivos_csv:
        try:
            print(f"Lendo cabeçalho de: {os.path.basename(arquivo)}")
            header = pd.read_csv(arquivo, encoding='latin1', sep=';', nrows=0).columns.str.upper()
            master_columns.update(header)
        except Exception as e:
            print(f"  Aviso: Não foi possível ler o cabeçalho de {os.path.basename(arquivo)}. Erro: {e}")

    novos_campos = [
        'REGIAO_CANDIDATO', 'FLAG_CAPITAL', 'REGIAO_ESCOLA', 'TIPO_ESCOLA_AGRUPADO', 
        'MEDIA_OBJETIVAS', 'MEDIA_GERAL', 'INDICADOR_ABSENTEISMO', 'INDICADOR_REDACAO_ZERADA',
        'RENDA_FAMILIAR', 'ESCOLARIDADE_PAIS_AGRUPADO', 'INDICE_ACESSO_TECNOLOGIA',
        'TEMPO_FORA_ESCOLA', 'FLAG_CANDIDATO_ADULTO'
    ]
    master_columns.update(novos_campos)
    master_columns_list = sorted(list(master_columns))
    
    tipos_de_dados_sql = {col: types.VARCHAR for col in master_columns_list}
    campos_numericos = ['NU_NOTA_CN', 'NU_NOTA_CH', 'NU_NOTA_LC', 'NU_NOTA_MT', 
                      'NU_NOTA_COMP1', 'NU_NOTA_COMP2', 'NU_NOTA_COMP3', 'NU_NOTA_COMP4', 
                      'NU_NOTA_COMP5', 'NU_NOTA_REDACAO', 'MEDIA_OBJETIVAS', 'MEDIA_GERAL']
    for col in campos_numericos:
        if col in tipos_de_dados_sql:
            tipos_de_dados_sql[col] = types.NUMERIC(10, 2)
    if 'NU_ANO' in tipos_de_dados_sql: 
        tipos_de_dados_sql['NU_ANO'] = types.INTEGER
    if 'TEMPO_FORA_ESCOLA' in tipos_de_dados_sql: 
        tipos_de_dados_sql['TEMPO_FORA_ESCOLA'] = types.INTEGER

    print(f"\nColunas totais que serão criadas na tabela: {len(master_columns_list)}")
    
    print("\n--- FASE 2: Processando e carregando arquivos para o PostgreSQL ---")
    is_first_upload = True
    
    with engine.connect() as connection:
        connection.execute(text(f'DROP TABLE IF EXISTS "{nome_tabela}" CASCADE;'))
        connection.commit()
    print(f"Tabela '{nome_tabela}' antiga (se existia) foi removida.")

    for arquivo in arquivos_csv:
        print(f"\nProcessando arquivo: {os.path.basename(arquivo)}")
        try:
            ano_str = ''.join(filter(str.isdigit, os.path.basename(arquivo)))
            ano_arquivo = int(ano_str) if ano_str else 0
        except ValueError:
            print(f"  Aviso: Não foi possível extrair o ano do nome do arquivo {os.path.basename(arquivo)}. Pulando.")
            continue
        
        reader = pd.read_csv(arquivo, encoding='latin1', sep=';', chunksize=chunk_size, low_memory=False)
        
        for i, chunk in enumerate(reader):
            chunk.columns = chunk.columns.str.upper()
            
            if 'NU_SEQUENCIAL' in chunk.columns:
                chunk.rename(columns={'NU_SEQUENCIAL': 'NU_INSCRICAO'}, inplace=True)
            
            campos_existentes = [col for col in campos_desejados if col in chunk.columns]
            chunk_processado = aplicar_regras_de_negocio(chunk[campos_existentes].copy(), ano_arquivo)
            chunk_alinhado = chunk_processado.reindex(columns=master_columns_list)

            print(f"  Chunk {i+1}: Enviando {len(chunk_alinhado)} linhas...", end="", flush=True)
            
            if_exists = 'replace' if is_first_upload else 'append'
            method = 'multi' if not is_first_upload else None  # Use bulk multi-row inserts for appends
            to_sql_kwargs = {
                'name': nome_tabela,
                'con': engine,
                'if_exists': if_exists,
                'index': False,
                'dtype': tipos_de_dados_sql,
                'method': method
            }
            # Add chunksize for appends to avoid param overflow
            if not is_first_upload:
                to_sql_kwargs['chunksize'] = upload_chunksize
            
            chunk_alinhado.to_sql(**to_sql_kwargs)
            print(" OK.")
            
            is_first_upload = False
            
    print(f"\nTodos os arquivos foram processados e carregados na tabela '{nome_tabela}'.")
    
    print("\n--- FASE 3: Verificando dados carregados no banco... ---")
    if is_first_upload:
        print("Nenhum dado foi carregado, a tabela não foi criada.")
    else:
        with engine.connect() as connection:
            query = text(f'SELECT "NU_ANO", COUNT(*) as total_registros FROM "{nome_tabela}" GROUP BY "NU_ANO" ORDER BY "NU_ANO";')
            df_verificacao = pd.read_sql_query(query, connection)
            print("Contagem de registros por ano na tabela final:")
            print(df_verificacao.to_string(index=False))
    
    engine.dispose()
    print("Pool de conexões liberado.")